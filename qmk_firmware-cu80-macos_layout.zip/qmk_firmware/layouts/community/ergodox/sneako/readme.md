# ergodox_keymap

Based on the default Ergodox EZ firmware

Replaced the left side Bksp with a Crtl/Esc, this really helps in vim.
Removed the Ctrls from the Z and / keys.
